document.addEventListener("DOMContentLoaded", () => {
  
 
  const tituloProfesional = document.getElementById("titulo-profesional");
  if (tituloProfesional) {
 
    tituloProfesional.textContent = "Ingeniero de Sistemas / Desarrollador Web";
  }

  
  const fotoPerfil = document.getElementById("foto-perfil");
  if (fotoPerfil) {
    fotoPerfil.style.borderColor = "#0d6efd";
    fotoPerfil.style.borderWidth = "3px";
  }

  const btnCambiarEstilo = document.getElementById("btn-cambiar-estilo");
  const tarjetaPerfil = document.getElementById("tarjeta-perfil");

  if (btnCambiarEstilo && tarjetaPerfil) {
    btnCambiarEstilo.addEventListener("click", () => {
      tarjetaPerfil.classList.toggle("tarjeta-destacada");
    });
  }

   if (fotoPerfil) {
    fotoPerfil.addEventListener("mouseover", () => {
      fotoPerfil.setAttribute("title", "Foto de perfil oficial");
    });
  }

  const formContacto = document.getElementById("form-contacto");
  const contenedorMensajes = document.getElementById("contenedor-mensajes");

  if (formContacto && contenedorMensajes) {
    formContacto.addEventListener("submit", (event) => {
      event.preventDefault(); // Evita recargar la página

      const nombre = document.getElementById("input-nombre").value;

      const nuevoMensaje = document.createElement("div");
      nuevoMensaje.classList.add("alerta-personalizada", "d-flex", "justify-content-between", "align-items-center", "mt-3");
      nuevoMensaje.innerHTML = `
        <span><strong>¡Gracias ${nombre}!</strong> Tu mensaje ha sido registrado con éxito.</span>
        <button class="btn-close ms-2" aria-label="Cerrar"></button>
      `;
      contenedorMensajes.appendChild(nuevoMensaje);
      const btnCerrar = nuevoMensaje.querySelector(".btn-close");
      btnCerrar.addEventListener("click", () => {
        nuevoMensaje.remove(); 
      });
      formContacto.reset();
    });
  }

});